package com.retail.types;

/**
 * @author Omer Dawelbeit (omerio)
 *
 */
public enum UserType {
    
    EMPLOYEE,
    AFFILIATE,
    CUSTOMER;

}
