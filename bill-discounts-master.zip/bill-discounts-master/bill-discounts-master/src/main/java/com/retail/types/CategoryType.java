package com.retail.types;

/**
 * @author Omer Dawelbeit (omerio)
 *
 */
public enum CategoryType {
    
    GROCERIES,
    CLOTHING,
    ELECTRONICS
    // etc...
    ;

}
