package com.retail.types;

/**
 * @author Omer Dawelbeit (omerio)
 *
 */
public enum DiscountType {
    
    PERCENTAGE,
    AMOUNT;

}
